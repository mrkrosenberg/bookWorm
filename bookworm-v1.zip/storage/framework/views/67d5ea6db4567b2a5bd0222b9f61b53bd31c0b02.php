<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card card-body book-info">
                <table class="table">
                    <tr>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Publication Date</th>
                    </tr>
                    <tr>
                        <td><?php echo e($book->title); ?></td>
                        <td><?php echo e($book->author); ?></td>
                        <td><?php echo e($book->pub_date); ?></td>
                    </tr>
                </table>
                <hr>
                <h6>Notes:</h6>
                <p><?php echo e($book->notes); ?></p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-body">
                    
                    <form action="/book/delete/<?php echo e($book->id); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <a class="btn btn-primary mb-5" href="/index">Back to List</a>
                        <br/>
                        <button class="btn btn-danger">Remove book from list</button>
                    </form>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>