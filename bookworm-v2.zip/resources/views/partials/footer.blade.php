<nav class="navbar navbar-dark bg-dark">
  <a class="navbar-brand" href="https://github.com/mrkrosenberg/bookWorm">Check out the code on Github!</a>
</nav>