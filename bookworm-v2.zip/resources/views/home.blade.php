@extends('layouts.main')

@section('content')

        <div class="header"> 
            <h1 class="main-title">Welcome to Bookworm</h1>
            <a href="/index" class="btn--main btn--white btn--animated">build your reading list</a>
        </div>

@endsection
