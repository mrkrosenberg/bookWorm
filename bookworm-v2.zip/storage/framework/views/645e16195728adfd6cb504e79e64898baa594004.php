<?php $__env->startSection('content'); ?>

        <div class="header"> 
            <h1 class="main-title">Welcome to Bookworm</h1>
            <a href="/index" class="btn--main btn--white btn--animated">build your reading list</a>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>